<?php
/**
 * @file
 * Default theme file for d3 visualizations.
 */
 ?>
<div <?php print $attributes ?> class="<?php print implode(' ', $classes_array); ?>"></div>
